# WebView Launcher

Aplikasi Android native (Java murni, 100% offline, tanpa izin internet)
dengan dua fitur inti: menjalankan proyek HTML lokal dan membaca PDF.

## Fitur

- Tab **HTML**: tambahkan `.zip` (berisi html/css/js dan file/folder
  pendukung lain, diekstrak otomatis, mencari `index.html`) atau file
  `.html` tunggal. Dibuka lewat WebView layar penuh dengan dukungan modul
  JavaScript dan fetch(). Tombol kembali menyusut jadi garis kecil di atas
  layar setelah 1.5 detik tak disentuh (ketuk garisnya untuk memunculkan
  lagi). Tanpa ikon manual, otomatis dapat ikon oranye (HTML) atau hijau
  (.zip).
- Tab **PDF**: dirender native lewat `PdfRenderer` bawaan Android, dengan
  cache halaman + pra-render halaman tetangga supaya navigasi antar halaman
  instan tanpa delay walau ditekan cepat berturut-turut atau PDF-nya
  panjang. Mendukung pinch-zoom pakai jari. Tombol kembali & navigasi
  halaman selalu terlihat (tidak menyusut). Tanpa ikon manual, otomatis
  dapat ikon merah.
- Tema warna ungu-toska gelap, seluruh ikon berupa gambar vector buatan
  sendiri (tanpa emoji/simbol bawaan sistem).
- Tekan lama pada ikon untuk menghapusnya.

## Cara build APK

Proyek ini adalah proyek Android Studio standar (Gradle, Java), dan
sekarang cukup ringan (tanpa dependency besar seperti pemutar video),
sehingga proses build lebih cepat dan lebih ringan untuk HP dengan RAM
terbatas.

1. Buka **Android Studio** → `Open` → pilih folder `WebViewLauncher`.
2. Tunggu proses Gradle sync selesai (butuh koneksi internet untuk mengunduh
   dependensi AndroidX pertama kali).
3. Klik `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`.
4. APK hasil build ada di `app/build/outputs/apk/debug/app-debug.apk`,
   tinggal salin ke HP dan pasang (aktifkan "Izinkan sumber tidak dikenal"
   bila diminta).

Alternatif tanpa Android Studio (jika sudah punya Android SDK & Gradle
terpasang di komputer):
```
cd WebViewLauncher
./gradlew assembleDebug
```
(jalankan `gradle wrapper` dulu jika file `gradlew` belum ada di folder ini).

Bisa juga dibangun lewat aplikasi IDE Android di HP seperti CodeAssist:
import folder ini sebagai proyek Gradle, lalu tekan tombol build di sana.

## Struktur singkat kode

- `MainActivity` — tab HTML/PDF (ViewPager2 + TabLayout)
- `GameFragment` / `DocumentFragment` — grid ikon per tab
- `AddGameActivity` / `AddDocumentActivity` — tambah item + ikon
- `WebGameActivity` — WebView layar penuh untuk proyek HTML, navigasi
  collapse-jadi-garis lewat `widget/CollapsibleNav`
- `DocumentViewerActivity` — penampil PDF dengan cache halaman & zoom
  lewat `widget/ZoomableImageView`
- `util/ZipExtractor` — ekstraksi zip & pencarian `index.html`
- `util/DocumentIconGenerator` — ikon otomatis (oranye HTML, hijau .zip,
  merah PDF)
- `data/DataStore` — penyimpanan daftar HTML/PDF ke JSON lokal
