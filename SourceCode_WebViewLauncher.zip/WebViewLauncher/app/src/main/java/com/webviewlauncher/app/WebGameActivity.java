package com.webviewlauncher.app;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;

import com.webviewlauncher.app.widget.CollapsibleNav;

import java.io.File;

/**
 * Menampilkan berkas HTML lokal (satu file atau proyek dengan banyak file/folder)
 * lewat WebView. Memakai WebViewAssetLoader agar halaman dianggap berasal dari
 * origin https:// lokal (bukan file://), sehingga modul JavaScript (type="module"),
 * fetch(), dan permintaan aset relatif tetap berfungsi normal walau sepenuhnya offline
 * (tidak ada koneksi internet sungguhan yang dipakai, hanya trik penyajian lokal).
 */
public class WebGameActivity extends AppCompatActivity {

    private static final String DOMAIN = "appassets.androidx.webkit.internal";

    private WebView webView;
    private FrameLayout customViewContainer;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private View exitButton;
    private CollapsibleNav collapsibleNav;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyImmersiveMode();
        setContentView(R.layout.activity_web_game);

        webView = findViewById(R.id.webView);
        customViewContainer = findViewById(R.id.customViewContainer);
        exitButton = findViewById(R.id.exitButton);
        View navLine = findViewById(R.id.navLine);

        exitButton.setOnClickListener(v -> finish());
        collapsibleNav = new CollapsibleNav(exitButton, navLine);

        String entryPath = getIntent().getStringExtra("entry_path");

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }

        String url;
        if (entryPath != null) {
            File entryFile = new File(entryPath);
            File gameRoot = resolveContentRoot(entryFile);

            WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                    .setDomain(DOMAIN)
                    .addPathHandler("/content/", new WebViewAssetLoader.InternalStoragePathHandler(this, gameRoot))
                    .build();

            webView.setWebViewClient(new WebViewClient() {
                @Nullable
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                    return assetLoader.shouldInterceptRequest(request.getUrl());
                }
            });

            String relative = relativePath(gameRoot, entryFile);
            url = "https://" + DOMAIN + "/content/" + relative;
        } else {
            url = null;
            webView.setWebViewClient(new WebViewClient());
        }

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                customViewContainer.addView(view);
                customViewContainer.setVisibility(View.VISIBLE);
                webView.setVisibility(View.GONE);
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                customViewContainer.removeView(customView);
                customViewContainer.setVisibility(View.GONE);
                webView.setVisibility(View.VISIBLE);
                customView = null;
                if (customViewCallback != null) {
                    customViewCallback.onCustomViewHidden();
                    customViewCallback = null;
                }
            }
        });

        if (url != null) {
            webView.loadUrl(url);
        }
    }

    /**
     * Mencari folder akar dari sebuah berkas HTML yang diekstrak, yaitu folder
     * langsung di bawah "games/" (folder ber-ID unik milik satu proyek HTML).
     */
    private File resolveContentRoot(File entryFile) {
        File gamesRoot = new File(getFilesDir(), "games");
        File current = entryFile;
        File child = current;
        while (current != null && !current.equals(gamesRoot)) {
            child = current;
            current = current.getParentFile();
        }
        return current != null ? child : entryFile.getParentFile();
    }

    private String relativePath(File root, File file) {
        String rootPath = root.getAbsolutePath();
        String filePath = file.getAbsolutePath();
        if (filePath.startsWith(rootPath)) {
            String rel = filePath.substring(rootPath.length());
            if (rel.startsWith(File.separator)) rel = rel.substring(1);
            return rel;
        }
        return file.getName();
    }

    private void applyImmersiveMode() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        View decor = getWindow().getDecorView();
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decor.setSystemUiVisibility(flags);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (customView != null) {
                webView.getWebChromeClient().onHideCustomView();
                return true;
            }
            if (webView.canGoBack()) {
                webView.goBack();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        if (collapsibleNav != null) collapsibleNav.destroy();
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
