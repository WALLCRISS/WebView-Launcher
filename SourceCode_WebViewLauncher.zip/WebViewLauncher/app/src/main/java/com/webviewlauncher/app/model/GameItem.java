package com.webviewlauncher.app.model;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Merepresentasikan satu game yang telah ditambahkan pengguna.
 * entryFilePath menunjuk ke berkas .html utama di dalam folder yang sudah diekstrak,
 * sehingga game dengan banyak file dan folder (seperti SpaceStrike) tetap bisa
 * memuat seluruh asetnya secara relatif melalui file://.
 */
public class GameItem {

    public String id;
    public String title;
    public String iconPath;
    public String entryFilePath;

    public GameItem() {
    }

    public GameItem(String id, String title, String iconPath, String entryFilePath) {
        this.id = id;
        this.title = title;
        this.iconPath = iconPath;
        this.entryFilePath = entryFilePath;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("title", title);
        o.put("iconPath", iconPath);
        o.put("entryFilePath", entryFilePath);
        return o;
    }

    public static GameItem fromJson(JSONObject o) throws JSONException {
        return new GameItem(
                o.getString("id"),
                o.getString("title"),
                o.optString("iconPath", ""),
                o.getString("entryFilePath")
        );
    }
}
