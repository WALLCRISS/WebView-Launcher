package com.webviewlauncher.app.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Mengekstrak berkas .zip (seperti SpaceStrike.zip yang berisi banyak folder dan file html)
 * ke sebuah folder tujuan di storage internal, lalu mencari berkas index.html sebagai
 * titik masuk game.
 */
public class ZipExtractor {

    /**
     * Mengekstrak seluruh isi zip dari inputStream ke destDir.
     */
    public static void extract(InputStream inputStream, File destDir) throws IOException {
        if (!destDir.exists()) destDir.mkdirs();

        try (ZipInputStream zis = new ZipInputStream(inputStream)) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];
            while ((entry = zis.getNextEntry()) != null) {
                File outFile = new File(destDir, entry.getName());

                // Cegah path traversal (zip slip)
                String canonicalDest = destDir.getCanonicalPath();
                String canonicalOut = outFile.getCanonicalPath();
                if (!canonicalOut.startsWith(canonicalDest + File.separator) && !canonicalOut.equals(canonicalDest)) {
                    continue;
                }

                if (entry.isDirectory()) {
                    outFile.mkdirs();
                } else {
                    File parent = outFile.getParentFile();
                    if (parent != null && !parent.exists()) parent.mkdirs();
                    try (OutputStream os = new BufferedOutputStream(new FileOutputStream(outFile))) {
                        int len;
                        while ((len = zis.read(buffer)) != -1) {
                            os.write(buffer, 0, len);
                        }
                    }
                }
                zis.closeEntry();
            }
        }
    }

    /**
     * Mencari berkas index.html (atau berkas .html lain bila tidak ada) di dalam folder,
     * dengan memprioritaskan file yang paling dekat dengan folder akar.
     */
    public static File findEntryHtml(File rootDir) {
        File direct = new File(rootDir, "index.html");
        if (direct.exists()) return direct;

        File best = null;
        int bestDepth = Integer.MAX_VALUE;
        File fallbackBest = null;
        int fallbackDepth = Integer.MAX_VALUE;

        best = searchRecursive(rootDir, rootDir, "index.html", 0);
        if (best != null) return best;

        fallbackBest = searchAnyHtml(rootDir, rootDir, 0);
        return fallbackBest;
    }

    private static File searchRecursive(File dir, File root, String targetName, int depth) {
        File[] files = dir.listFiles();
        if (files == null) return null;
        File found = null;
        int foundDepth = Integer.MAX_VALUE;
        for (File f : files) {
            if (f.isDirectory()) {
                File sub = searchRecursive(f, root, targetName, depth + 1);
                if (sub != null && depth + 1 < foundDepth) {
                    found = sub;
                    foundDepth = depth + 1;
                }
            } else if (f.getName().equalsIgnoreCase(targetName)) {
                if (depth < foundDepth) {
                    found = f;
                    foundDepth = depth;
                }
            }
        }
        return found;
    }

    private static File searchAnyHtml(File dir, File root, int depth) {
        File[] files = dir.listFiles();
        if (files == null) return null;
        for (File f : files) {
            if (f.isFile() && f.getName().toLowerCase().endsWith(".html")) {
                return f;
            }
        }
        for (File f : files) {
            if (f.isDirectory()) {
                File sub = searchAnyHtml(f, root, depth + 1);
                if (sub != null) return sub;
            }
        }
        return null;
    }
}
