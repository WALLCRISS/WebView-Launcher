package com.webviewlauncher.app.model;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Merepresentasikan satu dokumen (pdf, doc, docx, txt, md, dsb) yang ditambahkan pengguna.
 * documentUri menyimpan Uri asli dari penyimpanan (tidak disalin, hemat ruang),
 * dengan izin akses persisten yang diminta saat file dipilih.
 */
public class DocumentItem {

    public String id;
    public String title;
    public String iconPath;
    public String documentUri;
    public String extension;

    public DocumentItem() {
    }

    public DocumentItem(String id, String title, String iconPath, String documentUri, String extension) {
        this.id = id;
        this.title = title;
        this.iconPath = iconPath;
        this.documentUri = documentUri;
        this.extension = extension;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("title", title);
        o.put("iconPath", iconPath);
        o.put("documentUri", documentUri);
        o.put("extension", extension);
        return o;
    }

    public static DocumentItem fromJson(JSONObject o) throws JSONException {
        return new DocumentItem(
                o.getString("id"),
                o.getString("title"),
                o.optString("iconPath", ""),
                o.getString("documentUri"),
                o.optString("extension", "")
        );
    }
}
