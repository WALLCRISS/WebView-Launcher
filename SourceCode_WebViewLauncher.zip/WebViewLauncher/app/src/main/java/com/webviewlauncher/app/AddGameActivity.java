package com.webviewlauncher.app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;

import com.webviewlauncher.app.data.DataStore;
import com.webviewlauncher.app.model.GameItem;
import com.webviewlauncher.app.util.FileUtils;
import com.webviewlauncher.app.util.ZipExtractor;

import java.io.File;
import java.io.InputStream;
import java.util.List;

public class AddGameActivity extends AppCompatActivity {

    private ImageView iconPreview;
    private TextView fileNameText;
    private EditText nameInput;
    private ProgressBar progressBar;
    private Button saveButton;
    private Button pickFileButton;
    private Button pickIconButton;

    private Uri selectedFileUri;
    private Uri selectedIconUri;
    private String selectedFileName = "";

    private final ActivityResultLauncher<String[]> pickFileLauncher = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),
            uri -> {
                if (uri == null) return;
                selectedFileUri = uri;
                selectedFileName = queryDisplayName(uri);
                fileNameText.setText(selectedFileName);
            }
    );

    private final ActivityResultLauncher<String[]> pickIconLauncher = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),
            uri -> {
                if (uri == null) return;
                selectedIconUri = uri;
                try (InputStream is = getContentResolver().openInputStream(uri)) {
                    Bitmap bmp = BitmapFactory.decodeStream(is);
                    if (bmp != null) iconPreview.setImageBitmap(bmp);
                } catch (Exception ignored) {
                }
            }
    );

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_game);

        iconPreview = findViewById(R.id.iconPreview);
        fileNameText = findViewById(R.id.fileNameText);
        nameInput = findViewById(R.id.nameInput);
        progressBar = findViewById(R.id.progressBar);
        saveButton = findViewById(R.id.saveButton);
        pickFileButton = findViewById(R.id.pickFileButton);
        pickIconButton = findViewById(R.id.pickIconButton);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());

        pickIconButton.setOnClickListener(v -> pickIconLauncher.launch(new String[]{"image/*"}));
        pickFileButton.setOnClickListener(v -> pickFileLauncher.launch(new String[]{"*/*"}));

        saveButton.setOnClickListener(v -> onSaveClicked());
    }

    private void onSaveClicked() {
        String name = nameInput.getText().toString().trim();

        if (selectedFileUri == null) {
            Toast.makeText(this, R.string.error_pick_file, Toast.LENGTH_SHORT).show();
            return;
        }
        if (name.isEmpty()) {
            Toast.makeText(this, R.string.error_name, Toast.LENGTH_SHORT).show();
            return;
        }

        setLoading(true);

        new Thread(() -> {
            try {
                String id = FileUtils.randomId();
                File gameDir = new File(getFilesDir(), "games/" + id);
                gameDir.mkdirs();

                File entryFile;
                boolean isZip = selectedFileName.toLowerCase().endsWith(".zip");

                if (isZip) {
                    try (InputStream is = getContentResolver().openInputStream(selectedFileUri)) {
                        ZipExtractor.extract(is, gameDir);
                    }
                    entryFile = ZipExtractor.findEntryHtml(gameDir);
                } else {
                    File single = new File(gameDir, "index.html");
                    try (InputStream is = getContentResolver().openInputStream(selectedFileUri)) {
                        FileUtils.copyStreamToFile(is, single);
                    }
                    entryFile = single;
                }

                if (entryFile == null || !entryFile.exists()) {
                    runOnUiThread(() -> {
                        setLoading(false);
                        Toast.makeText(this, R.string.error_entry_not_found, Toast.LENGTH_LONG).show();
                    });
                    return;
                }

                String iconPath = "";
                File iconsDir = new File(getFilesDir(), "icons");
                iconsDir.mkdirs();
                File iconFile = new File(iconsDir, id + ".png");

                if (selectedIconUri != null) {
                    try (InputStream is = getContentResolver().openInputStream(selectedIconUri)) {
                        FileUtils.copyStreamToFile(is, iconFile);
                    }
                    iconPath = iconFile.getAbsolutePath();
                } else {
                    // Tidak ada ikon manual: beri ikon otomatis berwarna khas
                    // (oranye untuk HTML, hijau untuk proyek .zip)
                    String pseudoExtension = isZip ? "zip" : "html";
                    Bitmap generated =
                            com.webviewlauncher.app.util.DocumentIconGenerator.generate(pseudoExtension, 200);
                    try (java.io.FileOutputStream fos = new java.io.FileOutputStream(iconFile)) {
                        generated.compress(Bitmap.CompressFormat.PNG, 90, fos);
                    }
                    iconPath = iconFile.getAbsolutePath();
                }

                DataStore dataStore = new DataStore(this);
                List<GameItem> games = dataStore.loadGames();
                games.add(new GameItem(id, name, iconPath, entryFile.getAbsolutePath()));
                dataStore.saveGames(games);

                runOnUiThread(() -> {
                    setResult(Activity.RESULT_OK);
                    finish();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setLoading(false);
                    Toast.makeText(this, R.string.error_extract, Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        saveButton.setEnabled(!loading);
        pickFileButton.setEnabled(!loading);
        pickIconButton.setEnabled(!loading);
    }

    private String queryDisplayName(Uri uri) {
        String result = "";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = cursor.getString(idx);
            }
        } catch (Exception ignored) {
        }
        if (result == null || result.isEmpty()) {
            result = uri.getLastPathSegment();
        }
        return result == null ? "" : result;
    }
}
