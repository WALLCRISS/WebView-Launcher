package com.webviewlauncher.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.webviewlauncher.app.adapter.GameAdapter;
import com.webviewlauncher.app.data.DataStore;
import com.webviewlauncher.app.model.GameItem;
import com.webviewlauncher.app.util.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class GameFragment extends Fragment {

    private RecyclerView recyclerView;
    private TextView emptyText;
    private GameAdapter adapter;
    private final List<GameItem> items = new ArrayList<>();
    private DataStore dataStore;

    private final ActivityResultLauncher<Intent> addGameLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> reload()
    );

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_grid, container, false);

        dataStore = new DataStore(requireContext());
        recyclerView = root.findViewById(R.id.recyclerView);
        emptyText = root.findViewById(R.id.emptyText);
        emptyText.setText(R.string.empty_games);

        recyclerView.setLayoutManager(new GridLayoutManager(requireContext(), 3));
        adapter = new GameAdapter(items, new GameAdapter.Listener() {
            @Override
            public void onClick(GameItem item) {
                Intent intent = new Intent(requireContext(), WebGameActivity.class);
                intent.putExtra("entry_path", item.entryFilePath);
                intent.putExtra("title", item.title);
                startActivity(intent);
            }

            @Override
            public boolean onLongClick(GameItem item) {
                showDeleteDialog(item);
                return true;
            }
        });
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = root.findViewById(R.id.fab);
        fab.setOnClickListener(v -> addGameLauncher.launch(new Intent(requireContext(), AddGameActivity.class)));

        reload();
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        items.clear();
        items.addAll(dataStore.loadGames());
        adapter.notifyDataSetChanged();
        emptyText.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(items.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void showDeleteDialog(GameItem item) {
        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.delete_item_title)
                .setMessage(R.string.delete_item_message)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    // Hapus folder game yang telah diekstrak beserta ikonnya
                    if (item.entryFilePath != null) {
                        File entryFile = new File(item.entryFilePath);
                        File gameDir = entryFile.getParentFile();
                        // Naik ke folder root game (folder dengan nama id), bukan hanya sub-folder entry
                        File root = new File(requireContext().getFilesDir(), "games/" + item.id);
                        FileUtils.deleteRecursive(root);
                        if (gameDir != null && !gameDir.getAbsolutePath().equals(root.getAbsolutePath())) {
                            // no-op, root sudah mencakup semua isi
                        }
                    }
                    if (item.iconPath != null) {
                        FileUtils.deleteRecursive(new File(item.iconPath));
                    }
                    items.remove(item);
                    dataStore.saveGames(items);
                    adapter.notifyDataSetChanged();
                    emptyText.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
                    recyclerView.setVisibility(items.isEmpty() ? View.GONE : View.VISIBLE);
                })
                .show();
    }
}
