package com.webviewlauncher.app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;

import com.webviewlauncher.app.data.DataStore;
import com.webviewlauncher.app.model.DocumentItem;
import com.webviewlauncher.app.util.DocumentIconGenerator;
import com.webviewlauncher.app.util.FileUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Locale;

public class AddDocumentActivity extends AppCompatActivity {

    private ImageView iconPreview;
    private TextView fileNameText;
    private EditText nameInput;
    private ProgressBar progressBar;
    private Button saveButton;
    private Button pickFileButton;
    private Button pickIconButton;

    private Uri selectedDocumentUri;
    private Uri selectedIconUri;
    private String selectedFileName = "";

    private final ActivityResultLauncher<String[]> pickFileLauncher = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),
            uri -> {
                if (uri == null) return;
                selectedDocumentUri = uri;
                try {
                    getContentResolver().takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {
                }
                selectedFileName = queryDisplayName(uri);
                fileNameText.setText(selectedFileName);
                iconPreview.setImageBitmap(
                        DocumentIconGenerator.generate(extractExtension(selectedFileName), 200));
            }
    );

    private final ActivityResultLauncher<String[]> pickIconLauncher = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),
            uri -> {
                if (uri == null) return;
                selectedIconUri = uri;
                try (InputStream is = getContentResolver().openInputStream(uri)) {
                    Bitmap bmp = BitmapFactory.decodeStream(is);
                    if (bmp != null) iconPreview.setImageBitmap(bmp);
                } catch (Exception ignored) {
                }
            }
    );

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_document);

        iconPreview = findViewById(R.id.iconPreview);
        fileNameText = findViewById(R.id.fileNameText);
        nameInput = findViewById(R.id.nameInput);
        progressBar = findViewById(R.id.progressBar);
        saveButton = findViewById(R.id.saveButton);
        pickFileButton = findViewById(R.id.pickFileButton);
        pickIconButton = findViewById(R.id.pickIconButton);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());

        pickIconButton.setOnClickListener(v -> pickIconLauncher.launch(new String[]{"image/*"}));
        pickFileButton.setOnClickListener(v -> pickFileLauncher.launch(new String[]{"application/pdf"}));

        saveButton.setOnClickListener(v -> onSaveClicked());
    }

    private void onSaveClicked() {
        String name = nameInput.getText().toString().trim();

        if (selectedDocumentUri == null) {
            Toast.makeText(this, R.string.error_pick_file, Toast.LENGTH_SHORT).show();
            return;
        }
        if (name.isEmpty()) {
            Toast.makeText(this, R.string.error_name, Toast.LENGTH_SHORT).show();
            return;
        }

        setLoading(true);

        new Thread(() -> {
            try {
                String id = FileUtils.randomId();
                String extension = extractExtension(selectedFileName);

                File iconsDir = new File(getFilesDir(), "icons");
                iconsDir.mkdirs();
                File iconFile = new File(iconsDir, id + ".png");

                if (selectedIconUri != null) {
                    try (InputStream is = getContentResolver().openInputStream(selectedIconUri)) {
                        FileUtils.copyStreamToFile(is, iconFile);
                    }
                } else {
                    Bitmap generated = DocumentIconGenerator.generate(extension, 200);
                    try (FileOutputStream fos = new FileOutputStream(iconFile)) {
                        generated.compress(Bitmap.CompressFormat.PNG, 90, fos);
                    }
                }

                DataStore dataStore = new DataStore(this);
                List<DocumentItem> documents = dataStore.loadDocuments();
                documents.add(new DocumentItem(id, name, iconFile.getAbsolutePath(), selectedDocumentUri.toString(), extension));
                dataStore.saveDocuments(documents);

                runOnUiThread(() -> {
                    setResult(Activity.RESULT_OK);
                    finish();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setLoading(false);
                    Toast.makeText(this, R.string.error_extract, Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private String extractExtension(String fileName) {
        if (fileName == null) return "";
        int dot = fileName.lastIndexOf('.');
        if (dot < 0 || dot == fileName.length() - 1) return "";
        return fileName.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        saveButton.setEnabled(!loading);
        pickFileButton.setEnabled(!loading);
        pickIconButton.setEnabled(!loading);
    }

    private String queryDisplayName(Uri uri) {
        String result = "";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = cursor.getString(idx);
            }
        } catch (Exception ignored) {
        }
        if (result == null || result.isEmpty()) {
            result = uri.getLastPathSegment();
        }
        return result == null ? "" : result;
    }
}
