package com.webviewlauncher.app;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.util.DisplayMetrics;
import android.util.LruCache;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.webviewlauncher.app.widget.ZoomableImageView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Menampilkan berkas PDF secara penuh layar, dirender lewat PdfRenderer
 * bawaan Android (offline), dengan cache halaman + pra-render halaman
 * tetangga supaya navigasi antar halaman terasa instan tanpa delay meski
 * PDF-nya panjang dan tombol ditekan berkali-kali dengan cepat. Tombol
 * kembali dan navigasi halaman selalu terlihat (tidak menyusut/hilang).
 */
public class DocumentViewerActivity extends AppCompatActivity {

    private ZoomableImageView pdfPageImage;
    private View pdfNavPanel;
    private TextView pageIndicatorText;
    private ProgressBar loadingProgress;

    private ParcelFileDescriptor pdfFd;
    private PdfRenderer pdfRenderer;
    private int currentPage = 0;
    private int renderToken = 0;

    private final LruCache<Integer, Bitmap> pageCache = new LruCache<>(6);
    private final ExecutorService pdfExecutor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyImmersiveMode();
        setContentView(R.layout.activity_document_viewer);

        pdfPageImage = findViewById(R.id.pdfPageImage);
        pdfNavPanel = findViewById(R.id.pdfNavPanel);
        pageIndicatorText = findViewById(R.id.pageIndicatorText);
        loadingProgress = findViewById(R.id.loadingProgress);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        findViewById(R.id.prevPageButton).setOnClickListener(v -> showPage(currentPage - 1));
        findViewById(R.id.nextPageButton).setOnClickListener(v -> showPage(currentPage + 1));

        String uriString = getIntent().getStringExtra("document_uri");
        if (uriString == null) {
            Toast.makeText(this, R.string.error_pick_file, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        openPdf(Uri.parse(uriString));
    }

    private void openPdf(Uri uri) {
        loadingProgress.setVisibility(View.VISIBLE);
        pdfExecutor.execute(() -> {
            try {
                pdfFd = getContentResolver().openFileDescriptor(uri, "r");
                if (pdfFd == null) throw new IllegalStateException("Tidak bisa membuka berkas");
                pdfRenderer = new PdfRenderer(pdfFd);

                runOnUiThread(() -> {
                    loadingProgress.setVisibility(View.GONE);
                    pdfPageImage.setVisibility(View.VISIBLE);
                    pdfNavPanel.setVisibility(pdfRenderer.getPageCount() > 1 ? View.VISIBLE : View.GONE);
                    showPage(0);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    loadingProgress.setVisibility(View.GONE);
                    Toast.makeText(this, R.string.error_extract, Toast.LENGTH_SHORT).show();
                    finish();
                });
            }
        });
    }

    /**
     * Menampilkan halaman PDF dengan cache di memori + pra-render halaman
     * tetangga, supaya navigasi cepat berturut-turut tidak terasa delay atau
     * "melompat" ke halaman yang salah, walau PDF-nya berhalaman banyak.
     */
    private void showPage(int index) {
        if (pdfRenderer == null) return;
        if (index < 0 || index >= pdfRenderer.getPageCount()) return;
        currentPage = index;
        renderToken++;
        int myToken = renderToken;

        pageIndicatorText.setText(getString(R.string.page_indicator, currentPage + 1, pdfRenderer.getPageCount()));

        Bitmap cached = pageCache.get(index);
        if (cached != null) {
            pdfPageImage.setImageBitmap(cached);
        } else {
            renderPageAsync(index, bitmap -> {
                if (bitmap == null) return;
                pageCache.put(index, bitmap);
                if (myToken == renderToken) {
                    pdfPageImage.setImageBitmap(bitmap);
                }
            });
        }

        prefetch(index + 1);
        prefetch(index - 1);
    }

    private void prefetch(int index) {
        if (pdfRenderer == null || index < 0 || index >= pdfRenderer.getPageCount()) return;
        if (pageCache.get(index) != null) return;
        renderPageAsync(index, bitmap -> {
            if (bitmap != null) pageCache.put(index, bitmap);
        });
    }

    private interface BitmapCallback {
        void onResult(@Nullable Bitmap bitmap);
    }

    private void renderPageAsync(int index, BitmapCallback callback) {
        pdfExecutor.execute(() -> {
            Bitmap bitmap = null;
            try {
                PdfRenderer.Page page = pdfRenderer.openPage(index);

                DisplayMetrics metrics = getResources().getDisplayMetrics();
                int screenMax = Math.max(metrics.widthPixels, metrics.heightPixels);
                int targetWidth = Math.min(screenMax * 2, 2400);
                float scale = targetWidth / (float) page.getWidth();
                int width = Math.max(1, Math.round(page.getWidth() * scale));
                int height = Math.max(1, Math.round(page.getHeight() * scale));

                bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                bitmap.eraseColor(Color.WHITE);
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                page.close();
            } catch (Exception ignored) {
            }
            Bitmap finalBitmap = bitmap;
            runOnUiThread(() -> callback.onResult(finalBitmap));
        });
    }

    private void applyImmersiveMode() {
        View decor = getWindow().getDecorView();
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decor.setSystemUiVisibility(flags);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }

    @Override
    protected void onDestroy() {
        pdfExecutor.shutdownNow();
        try {
            if (pdfRenderer != null) pdfRenderer.close();
            if (pdfFd != null) pdfFd.close();
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }
}
