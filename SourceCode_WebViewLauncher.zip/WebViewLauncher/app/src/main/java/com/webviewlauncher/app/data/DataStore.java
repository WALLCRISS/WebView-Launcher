package com.webviewlauncher.app.data;

import android.content.Context;

import com.webviewlauncher.app.model.GameItem;
import com.webviewlauncher.app.model.DocumentItem;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Penyimpanan sederhana berbasis berkas JSON di storage internal aplikasi.
 * Tidak memerlukan database eksternal, sepenuhnya offline.
 */
public class DataStore {

    private static final String GAMES_FILE = "games.json";
    private static final String DOCUMENTS_FILE = "documents.json";

    private final File gamesFile;
    private final File documentsFile;

    public DataStore(Context context) {
        gamesFile = new File(context.getFilesDir(), GAMES_FILE);
        documentsFile = new File(context.getFilesDir(), DOCUMENTS_FILE);
    }

    public synchronized List<GameItem> loadGames() {
        List<GameItem> list = new ArrayList<>();
        String content = readFile(gamesFile);
        if (content == null) return list;
        try {
            JSONArray arr = new JSONArray(content);
            for (int i = 0; i < arr.length(); i++) {
                list.add(GameItem.fromJson(arr.getJSONObject(i)));
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public synchronized void saveGames(List<GameItem> items) {
        try {
            JSONArray arr = new JSONArray();
            for (GameItem item : items) arr.put(item.toJson());
            writeFile(gamesFile, arr.toString());
        } catch (Exception ignored) {
        }
    }

    public synchronized List<DocumentItem> loadDocuments() {
        List<DocumentItem> list = new ArrayList<>();
        String content = readFile(documentsFile);
        if (content == null) return list;
        try {
            JSONArray arr = new JSONArray(content);
            for (int i = 0; i < arr.length(); i++) {
                list.add(DocumentItem.fromJson(arr.getJSONObject(i)));
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public synchronized void saveDocuments(List<DocumentItem> items) {
        try {
            JSONArray arr = new JSONArray();
            for (DocumentItem item : items) arr.put(item.toJson());
            writeFile(documentsFile, arr.toString());
        } catch (Exception ignored) {
        }
    }

    private String readFile(File file) {
        if (!file.exists()) return null;
        try (FileInputStream fis = new FileInputStream(file)) {
            StringBuilder sb = new StringBuilder();
            InputStreamReader reader = new InputStreamReader(fis, StandardCharsets.UTF_8);
            char[] buffer = new char[4096];
            int read;
            while ((read = reader.read(buffer)) != -1) {
                sb.append(buffer, 0, read);
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private void writeFile(File file, String content) {
        try (FileOutputStream fos = new FileOutputStream(file, false)) {
            fos.write(content.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {
        }
    }
}
