package com.webviewlauncher.app;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class LauncherPagerAdapter extends FragmentStateAdapter {

    public LauncherPagerAdapter(@NonNull FragmentActivity activity) {
        super(activity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        if (position == 0) return new GameFragment();
        return new DocumentFragment();
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
