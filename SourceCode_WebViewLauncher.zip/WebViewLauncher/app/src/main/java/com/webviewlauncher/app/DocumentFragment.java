package com.webviewlauncher.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.webviewlauncher.app.adapter.DocumentAdapter;
import com.webviewlauncher.app.data.DataStore;
import com.webviewlauncher.app.model.DocumentItem;
import com.webviewlauncher.app.util.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DocumentFragment extends Fragment {

    private RecyclerView recyclerView;
    private TextView emptyText;
    private DocumentAdapter adapter;
    private final List<DocumentItem> items = new ArrayList<>();
    private DataStore dataStore;

    private final ActivityResultLauncher<Intent> addDocumentLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> reload()
    );

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_grid, container, false);

        dataStore = new DataStore(requireContext());
        recyclerView = root.findViewById(R.id.recyclerView);
        emptyText = root.findViewById(R.id.emptyText);
        emptyText.setText(R.string.empty_documents);

        recyclerView.setLayoutManager(new GridLayoutManager(requireContext(), 3));
        adapter = new DocumentAdapter(items, new DocumentAdapter.Listener() {
            @Override
            public void onClick(DocumentItem item) {
                Intent intent = new Intent(requireContext(), DocumentViewerActivity.class);
                intent.putExtra("document_uri", item.documentUri);
                intent.putExtra("title", item.title);
                intent.putExtra("extension", item.extension);
                startActivity(intent);
            }

            @Override
            public boolean onLongClick(DocumentItem item) {
                showDeleteDialog(item);
                return true;
            }
        });
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = root.findViewById(R.id.fab);
        fab.setOnClickListener(v -> addDocumentLauncher.launch(new Intent(requireContext(), AddDocumentActivity.class)));

        reload();
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        items.clear();
        items.addAll(dataStore.loadDocuments());
        adapter.notifyDataSetChanged();
        emptyText.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(items.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void showDeleteDialog(DocumentItem item) {
        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.delete_item_title)
                .setMessage(R.string.delete_item_message)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    if (item.iconPath != null) {
                        FileUtils.deleteRecursive(new File(item.iconPath));
                    }
                    items.remove(item);
                    dataStore.saveDocuments(items);
                    adapter.notifyDataSetChanged();
                    emptyText.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
                    recyclerView.setVisibility(items.isEmpty() ? View.GONE : View.VISIBLE);
                })
                .show();
    }
}
