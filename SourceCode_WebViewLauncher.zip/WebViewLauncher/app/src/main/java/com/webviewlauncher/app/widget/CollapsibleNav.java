package com.webviewlauncher.app.widget;

import android.os.Handler;
import android.os.Looper;
import android.view.View;

/**
 * Mengatur perilaku "collapse jadi garis pendek" untuk sekelompok kontrol navigasi
 * (dipakai khusus di layar HTML). Setelah 1.5 detik tanpa disentuh, kelompok
 * kontrol menyusut dan hilang, digantikan sebuah garis kecil di posisi yang
 * sama. Menyentuh garis itu akan memunculkan kembali kontrol lengkapnya.
 */
public class CollapsibleNav {

    private static final long IDLE_DELAY_MS = 1500;

    private final View expandedGroup;
    private final View collapsedLine;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean collapsed = false;

    private final Runnable collapseRunnable = this::collapse;

    public CollapsibleNav(View expandedGroup, View collapsedLine) {
        this.expandedGroup = expandedGroup;
        this.collapsedLine = collapsedLine;
        collapsedLine.setOnClickListener(v -> expand());
        collapsedLine.setVisibility(View.GONE);
        collapsedLine.setAlpha(0f);
        scheduleCollapse();
    }

    /** Dipanggil setiap ada interaksi supaya timer idle diulang dari awal. */
    public void keepAlive() {
        if (collapsed) {
            expand();
        } else {
            scheduleCollapse();
        }
    }

    private void scheduleCollapse() {
        handler.removeCallbacks(collapseRunnable);
        handler.postDelayed(collapseRunnable, IDLE_DELAY_MS);
    }

    private void collapse() {
        collapsed = true;
        expandedGroup.animate()
                .alpha(0f)
                .scaleX(0.85f)
                .scaleY(0.85f)
                .setDuration(250)
                .withEndAction(() -> expandedGroup.setVisibility(View.GONE))
                .start();

        collapsedLine.setVisibility(View.VISIBLE);
        collapsedLine.setAlpha(0f);
        collapsedLine.animate().alpha(1f).setDuration(250).start();
    }

    private void expand() {
        collapsed = false;
        collapsedLine.animate()
                .alpha(0f)
                .setDuration(200)
                .withEndAction(() -> collapsedLine.setVisibility(View.GONE))
                .start();

        expandedGroup.setVisibility(View.VISIBLE);
        expandedGroup.setAlpha(0f);
        expandedGroup.setScaleX(0.85f);
        expandedGroup.setScaleY(0.85f);
        expandedGroup.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(250)
                .start();

        scheduleCollapse();
    }

    public void destroy() {
        handler.removeCallbacksAndMessages(null);
    }
}
