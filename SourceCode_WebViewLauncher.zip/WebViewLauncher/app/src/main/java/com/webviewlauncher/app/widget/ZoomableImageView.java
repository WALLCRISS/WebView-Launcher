package com.webviewlauncher.app.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ViewParent;

import androidx.appcompat.widget.AppCompatImageView;

/**
 * ImageView yang mendukung cubit dua jari untuk memperbesar/memperkecil (pinch zoom)
 * dan menggeser gambar dengan jari di posisi mana saja pada gambar, dipakai untuk
 * menampilkan halaman dokumen (PDF) agar pengguna bisa memperbesar bagian yang ingin
 * dibaca lebih jelas. Ketuk dua kali untuk memperbesar/mengembalikan ke ukuran semula.
 */
public class ZoomableImageView extends AppCompatImageView {

    private static final float MAX_EXTRA_SCALE = 6f;
    private static final float MIN_EXTRA_SCALE = 1f;
    private static final float DOUBLE_TAP_SCALE = 3f;

    private final Matrix baseMatrix = new Matrix();
    private final Matrix suppMatrix = new Matrix();
    private final Matrix drawMatrix = new Matrix();

    private float currentExtraScale = 1f;
    private int drawableWidth;
    private int drawableHeight;

    private ScaleGestureDetector scaleGestureDetector;
    private GestureDetector gestureDetector;

    private float lastX, lastY;
    private int activePointerId = -1;
    private boolean isDragging = false;

    public ZoomableImageView(Context context) {
        this(context, null);
    }

    public ZoomableImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        setScaleType(ScaleType.MATRIX);
        scaleGestureDetector = new ScaleGestureDetector(context, new ScaleListener());
        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                onDoubleTapZoom(e.getX(), e.getY());
                return true;
            }
        });
    }

    @Override
    public void setImageBitmap(Bitmap bm) {
        super.setImageBitmap(bm);
        drawableWidth = bm != null ? bm.getWidth() : 0;
        drawableHeight = bm != null ? bm.getHeight() : 0;
        resetZoom();
    }

    @Override
    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        drawableWidth = drawable != null ? drawable.getIntrinsicWidth() : 0;
        drawableHeight = drawable != null ? drawable.getIntrinsicHeight() : 0;
        resetZoom();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        resetZoom();
    }

    /** Mengembalikan gambar ke skala pas-layar (fit) dan posisi tengah. */
    public void resetZoom() {
        suppMatrix.reset();
        currentExtraScale = 1f;
        computeBaseFitMatrix();
        applyMatrix();
    }

    private void computeBaseFitMatrix() {
        baseMatrix.reset();
        int viewWidth = getWidth();
        int viewHeight = getHeight();
        if (drawableWidth <= 0 || drawableHeight <= 0 || viewWidth <= 0 || viewHeight <= 0) return;

        float scale = Math.min(viewWidth / (float) drawableWidth, viewHeight / (float) drawableHeight);
        float dx = (viewWidth - drawableWidth * scale) / 2f;
        float dy = (viewHeight - drawableHeight * scale) / 2f;
        baseMatrix.postScale(scale, scale);
        baseMatrix.postTranslate(dx, dy);
    }

    private void applyMatrix() {
        drawMatrix.set(baseMatrix);
        drawMatrix.postConcat(suppMatrix);
        setImageMatrix(drawMatrix);
    }

    private void onDoubleTapZoom(float focusX, float focusY) {
        if (currentExtraScale > 1.05f) {
            resetZoom();
        } else {
            float factor = DOUBLE_TAP_SCALE / currentExtraScale;
            suppMatrix.postScale(factor, factor, focusX, focusY);
            currentExtraScale = DOUBLE_TAP_SCALE;
            constrainTranslation();
            applyMatrix();
        }
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            float factor = detector.getScaleFactor();
            float newScale = currentExtraScale * factor;
            newScale = Math.max(MIN_EXTRA_SCALE, Math.min(MAX_EXTRA_SCALE, newScale));
            float appliedFactor = newScale / currentExtraScale;
            if (appliedFactor != 1f) {
                suppMatrix.postScale(appliedFactor, appliedFactor, detector.getFocusX(), detector.getFocusY());
                currentExtraScale = newScale;
                constrainTranslation();
                applyMatrix();
            }
            return true;
        }
    }

    /** Menjaga agar gambar tidak tergeser sampai meninggalkan area layar sepenuhnya. */
    private void constrainTranslation() {
        if (drawableWidth <= 0 || drawableHeight <= 0) return;
        RectF rect = new RectF(0, 0, drawableWidth, drawableHeight);
        Matrix combined = new Matrix(baseMatrix);
        combined.postConcat(suppMatrix);
        combined.mapRect(rect);

        int viewWidth = getWidth();
        int viewHeight = getHeight();
        float dx = 0f;
        float dy = 0f;

        if (rect.width() <= viewWidth) {
            dx = (viewWidth - rect.width()) / 2f - rect.left;
        } else {
            if (rect.left > 0) dx = -rect.left;
            else if (rect.right < viewWidth) dx = viewWidth - rect.right;
        }

        if (rect.height() <= viewHeight) {
            dy = (viewHeight - rect.height()) / 2f - rect.top;
        } else {
            if (rect.top > 0) dy = -rect.top;
            else if (rect.bottom < viewHeight) dy = viewHeight - rect.bottom;
        }

        if (dx != 0f || dy != 0f) {
            suppMatrix.postTranslate(dx, dy);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleGestureDetector.onTouchEvent(event);
        gestureDetector.onTouchEvent(event);

        ViewParent parent = getParent();

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = event.getX();
                lastY = event.getY();
                activePointerId = event.getPointerId(0);
                isDragging = false;
                if (parent != null) parent.requestDisallowInterceptTouchEvent(true);
                break;

            case MotionEvent.ACTION_MOVE:
                if (!scaleGestureDetector.isInProgress() && activePointerId != -1) {
                    int pointerIndex = event.findPointerIndex(activePointerId);
                    if (pointerIndex != -1) {
                        float x = event.getX(pointerIndex);
                        float y = event.getY(pointerIndex);
                        float dx = x - lastX;
                        float dy = y - lastY;
                        if (!isDragging && (Math.abs(dx) > 6 || Math.abs(dy) > 6)) {
                            isDragging = true;
                        }
                        if (isDragging && currentExtraScale > 1.01f) {
                            suppMatrix.postTranslate(dx, dy);
                            constrainTranslation();
                            applyMatrix();
                        }
                        lastX = x;
                        lastY = y;
                    }
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                activePointerId = -1;
                isDragging = false;
                if (parent != null) parent.requestDisallowInterceptTouchEvent(false);
                break;

            default:
                break;
        }
        return true;
    }
}
