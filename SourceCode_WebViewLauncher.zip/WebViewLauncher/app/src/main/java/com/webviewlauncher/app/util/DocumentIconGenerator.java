package com.webviewlauncher.app.util;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Menghasilkan ikon persegi bulat dengan warna dan label singkat: oranye untuk
 * HTML, hijau untuk proyek .zip, merah untuk PDF -- dipakai saat pengguna
 * tidak mengunggah ikon sendiri.
 */
public class DocumentIconGenerator {

    private static final Map<String, Integer> COLOR_MAP = new HashMap<>();
    private static final int DEFAULT_COLOR = Color.parseColor("#6E7379");

    static {
        COLOR_MAP.put("pdf", Color.parseColor("#C0392B"));
        COLOR_MAP.put("html", Color.parseColor("#E44D26"));
        COLOR_MAP.put("zip", Color.parseColor("#2E8B3D"));
    }

    public static Bitmap generate(String extension, int sizePx) {
        String ext = extension == null ? "" : extension.toLowerCase(Locale.ROOT);
        int color = COLOR_MAP.containsKey(ext) ? COLOR_MAP.get(ext) : DEFAULT_COLOR;
        String label = ext.isEmpty() ? "FILE" : (ext.length() > 4 ? ext.substring(0, 4) : ext).toUpperCase(Locale.ROOT);

        Bitmap bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bgPaint.setColor(color);
        RectF rect = new RectF(0, 0, sizePx, sizePx);
        float radius = sizePx * 0.18f;
        canvas.drawRoundRect(rect, radius, radius, bgPaint);

        // Sudut kanan atas dilipat sedikit, menyerupai bentuk berkas dokumen
        Paint foldPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        foldPaint.setColor(Color.argb(60, 255, 255, 255));
        float foldSize = sizePx * 0.22f;
        android.graphics.Path foldPath = new android.graphics.Path();
        foldPath.moveTo(sizePx - foldSize, 0);
        foldPath.lineTo(sizePx, foldSize);
        foldPath.lineTo(sizePx - foldSize, foldSize);
        foldPath.close();
        canvas.drawPath(foldPath, foldPaint);

        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD));
        textPaint.setTextSize(sizePx * 0.24f);

        float textY = sizePx / 2f - (textPaint.descent() + textPaint.ascent()) / 2f + sizePx * 0.06f;
        canvas.drawText(label, sizePx / 2f, textY, textPaint);

        return bitmap;
    }
}
