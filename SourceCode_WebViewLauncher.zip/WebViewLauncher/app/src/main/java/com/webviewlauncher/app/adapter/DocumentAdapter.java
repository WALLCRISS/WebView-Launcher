package com.webviewlauncher.app.adapter;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.webviewlauncher.app.R;
import com.webviewlauncher.app.model.DocumentItem;

import java.io.File;
import java.util.List;

public class DocumentAdapter extends RecyclerView.Adapter<DocumentAdapter.VH> {

    public interface Listener {
        void onClick(DocumentItem item);
        boolean onLongClick(DocumentItem item);
    }

    private final List<DocumentItem> items;
    private final Listener listener;

    public DocumentAdapter(List<DocumentItem> items, Listener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_document, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        DocumentItem item = items.get(position);
        holder.title.setText(item.title);

        Bitmap bmp = null;
        if (item.iconPath != null && !item.iconPath.isEmpty()) {
            File f = new File(item.iconPath);
            if (f.exists()) {
                bmp = BitmapFactory.decodeFile(f.getAbsolutePath());
            }
        }
        if (bmp != null) {
            holder.icon.setImageBitmap(bmp);
        } else {
            holder.icon.setImageResource(R.drawable.ic_document_placeholder);
        }

        holder.itemView.setOnClickListener(v -> listener.onClick(item));
        holder.itemView.setOnLongClickListener(v -> listener.onLongClick(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        ImageView icon;
        TextView title;

        VH(@NonNull View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.icon);
            title = itemView.findViewById(R.id.title);
        }
    }
}
